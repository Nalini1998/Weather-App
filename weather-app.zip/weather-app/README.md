# Weather App

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/BavBdmp/5ca6952cab6128e1ddb704c8a3311601](https://codepen.io/Nalini1998/pen/BavBdmp/5ca6952cab6128e1ddb704c8a3311601).

# Weather App

This is a simple web application that displays the weather information of a particular city. The user can search for the city name and select the country from the dropdown list, then click on the "Get Weather" button to fetch the current weather data using OpenWeatherMap API.

## Technologies Used

- HTML
- CSS
- JavaScript
- Bootstrap
- jQuery

## API Used

- OpenWeatherMap API

## How It Works

- The user enters their desired city name in the search bar and selects a country from the dropdown list.
- On clicking the "Get Weather" button, the application sends a request to the OpenWeatherMap API using fetch() method.
- The API responds with a JSON object containing the weather data.
- The application updates the weather information on the page such as temperature, condition, and city name, and also updates the weather icon image according to the weather condition.
- If there is any error in fetching the data, the application displays a friendly error message to the user.

## Future Upgrades

We can add more features to this application like:

- Displaying a 5-day weather forecast for a city.
- Allowing users to toggle between Celsius and Fahrenheit scales for temperature.
- Adding more relevant information about the weather condition like air quality, humidity, wind speed etc.

## Setup Instructions

1. Clone this repository to your local machine.
2. Open the `index.html` file in your web browser.
3. To start using the weather app, enter a city name and select the country from the dropdown menu, then click on the "Get Weather" button.
4. To make any changes to the application, edit the files using a text editor and refresh the `index.html` page in your web browser to see the changes.